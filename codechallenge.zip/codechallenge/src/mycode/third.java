package mycode;
import java.lang.Math;
public class third {

	public static void main(String[] args) {
		double mass=5.972*(Math.pow(10, 24));
		System.out.printf("%.0f", mass);

	}

}
